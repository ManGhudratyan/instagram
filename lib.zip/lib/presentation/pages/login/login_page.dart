// import 'package:flutter/material.dart';

// import '../../constants/assets.dart';

// class LoginPage extends StatefulWidget {
//   const LoginPage({super.key});

//   @override
//   State<LoginPage> createState() => _LoginPageState();
// }

// class _LoginPageState extends State<LoginPage> {
//   final TextEditingController _nameController = TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Image.asset(Assets.instagramLogo),
//           TextFormField(
//             controller: _nameController,
//             decoration: InputDecoration(hintText: 'Username, email address'),
//           ),
//         ],
//       ),
//     );
//   }
// }
