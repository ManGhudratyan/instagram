// ignore_for_file: avoid_classes_with_only_static_members

abstract class Constants {
  static double get loginImageSize => 300;
  static double get socialImageWidth => 25;
  static double get socialImageHeight => 28;
}
